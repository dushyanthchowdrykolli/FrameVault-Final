import React from 'react';
import { HashRouter, Routes, Route, Navigate } from 'react-router-dom';
import Login from './pages/Login';
import Dashboard from './pages/Dashboard';
import AlbumView from './pages/AlbumView';
import ShareView from './pages/ShareView';
import NotFound from './pages/NotFound';

// Simple route protection
const ProtectedRoute = ({ children }: { children: React.ReactNode }) => {
  const user = localStorage.getItem('user');
  if (!user) {
    return <Navigate to="/login" replace />;
  }
  return <>{children}</>;
};

const App: React.FC = () => {
  return (
    <HashRouter>
      <Routes>
        <Route path="/login" element={<Login />} />
        
        {/* Protected Routes */}
        <Route path="/" element={
          <ProtectedRoute>
            <Dashboard />
          </ProtectedRoute>
        } />
        <Route path="/album/:id" element={
          <ProtectedRoute>
            <AlbumView />
          </ProtectedRoute>
        } />

        {/* Public Share Route */}
        <Route path="/s/:token" element={<ShareView />} />

        <Route path="*" element={<NotFound />} />
      </Routes>
    </HashRouter>
  );
};

export default App;