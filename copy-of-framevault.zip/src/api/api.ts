import axios from 'axios';
import { Album, Photo, Share, User } from '../../types';

const API_URL = 'http://localhost:4000';

const api = axios.create({
  baseURL: API_URL,
});

// User
export const getUsers = async () => {
  const response = await api.get<User[]>('/users');
  return response.data;
};

// Albums
export const getAlbums = async () => {
  const response = await api.get<Album[]>('/albums?_sort=date&_order=desc');
  return response.data;
};

export const getAlbumById = async (id: string) => {
  const response = await api.get<Album>(`/albums/${id}`);
  return response.data;
};

export const createAlbum = async (album: Omit<Album, 'id'>) => {
  const response = await api.post<Album>('/albums', album);
  return response.data;
};

// Photos
export const getPhotosByAlbum = async (albumId: string) => {
  const response = await api.get<Photo[]>(`/photos?albumId=${albumId}&_sort=dateAdded&_order=desc`);
  return response.data;
};

export const addPhoto = async (photo: Omit<Photo, 'id'>) => {
  const response = await api.post<Photo>('/photos', photo);
  return response.data;
};

// Shares
export const createShare = async (share: Omit<Share, 'id'>) => {
  const response = await api.post<Share>('/shares', share);
  return response.data;
};

export const getShareByToken = async (token: string) => {
  const response = await api.get<Share[]>(`/shares?token=${token}`);
  return response.data[0]; // JSON Server returns array for filters
};
