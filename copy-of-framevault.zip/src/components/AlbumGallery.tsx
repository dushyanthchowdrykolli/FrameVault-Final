import React from 'react';
import { Photo } from '../../types';

interface AlbumGalleryProps {
  photos: Photo[];
}

const AlbumGallery: React.FC<AlbumGalleryProps> = ({ photos }) => {
  if (photos.length === 0) {
    return (
      <div className="text-center py-10 bg-white rounded-lg shadow-sm border border-dashed border-gray-300">
        <p className="text-gray-500">No photos in this album yet.</p>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
      {photos.map((photo) => (
        <div 
          key={photo.id} 
          className="group relative aspect-square bg-gray-100 rounded-lg overflow-hidden shadow-sm hover:shadow-md transition-all"
        >
          <img 
            src={photo.url} 
            alt="Album content" 
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
          />
          <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-10 transition-opacity" />
        </div>
      ))}
    </div>
  );
};

export default AlbumGallery;