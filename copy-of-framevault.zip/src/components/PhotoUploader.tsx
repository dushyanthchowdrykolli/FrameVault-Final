import React, { useState } from 'react';

interface PhotoUploaderProps {
  onUpload: (fileUrl: string) => void;
}

const PhotoUploader: React.FC<PhotoUploaderProps> = ({ onUpload }) => {
  const [preview, setPreview] = useState<string | null>(null);
  const [isUploading, setIsUploading] = useState(false);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      // Create a fake URL for the "upload"
      const objectUrl = URL.createObjectURL(file);
      setPreview(objectUrl);
    }
  };

  const handleUploadClick = () => {
    if (preview) {
      setIsUploading(true);
      // Simulate network delay
      setTimeout(() => {
        onUpload(preview);
        setPreview(null);
        setIsUploading(false);
      }, 800);
    }
  };

  return (
    <div className="bg-white p-4 rounded-lg shadow-md border border-gray-100 mb-6">
      <h3 className="font-semibold text-gray-800 mb-4">Upload New Photo</h3>
      
      {!preview ? (
        <div className="flex items-center justify-center w-full">
          <label htmlFor="dropzone-file" className="flex flex-col items-center justify-center w-full h-32 border-2 border-gray-300 border-dashed rounded-lg cursor-pointer bg-gray-50 hover:bg-gray-100">
            <div className="flex flex-col items-center justify-center pt-5 pb-6">
              <p className="mb-2 text-sm text-gray-500"><span className="font-semibold">Click to upload</span></p>
              <p className="text-xs text-gray-500">JPG or PNG</p>
            </div>
            <input id="dropzone-file" type="file" className="hidden" accept="image/*" onChange={handleFileChange} />
          </label>
        </div>
      ) : (
        <div className="flex flex-col items-center">
          <div className="relative w-32 h-32 mb-4 rounded-lg overflow-hidden border border-gray-300">
             <img src={preview} alt="Preview" className="w-full h-full object-cover" />
          </div>
          <div className="flex gap-2">
            <button 
              onClick={() => setPreview(null)}
              className="px-4 py-2 text-sm text-gray-600 bg-gray-200 rounded-md hover:bg-gray-300"
              disabled={isUploading}
            >
              Cancel
            </button>
            <button 
              onClick={handleUploadClick}
              className="px-4 py-2 text-sm text-white bg-brand-600 rounded-md hover:bg-brand-700 disabled:opacity-50"
              disabled={isUploading}
            >
              {isUploading ? 'Uploading...' : 'Confirm Upload'}
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default PhotoUploader;