import React from 'react';
import { Album } from '../../types';

interface AlbumCardProps {
  album: Album;
  onClick: () => void;
}

const AlbumCard: React.FC<AlbumCardProps> = ({ album, onClick }) => {
  return (
    <div 
      onClick={onClick}
      className="bg-white rounded-lg shadow-md hover:shadow-lg hover:scale-[1.01] transition-all duration-200 cursor-pointer overflow-hidden border border-gray-100"
    >
      <div className="h-40 w-full bg-gray-200 relative">
        {album.coverUrl ? (
          <img 
            src={album.coverUrl} 
            alt={album.title} 
            className="w-full h-full object-cover"
          />
        ) : (
          <div className="flex items-center justify-center h-full text-gray-400">
            No Cover
          </div>
        )}
      </div>
      <div className="p-4">
        <h3 className="font-bold text-lg text-gray-800 truncate">{album.title}</h3>
        <p className="text-gray-500 text-sm mt-1">{new Date(album.date).toLocaleDateString()}</p>
        <button className="mt-3 text-sm text-brand-600 font-medium hover:underline">
          View Album →
        </button>
      </div>
    </div>
  );
};

export default AlbumCard;