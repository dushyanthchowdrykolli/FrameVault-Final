import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Header from '../components/Header';
import AlbumCard from '../components/AlbumCard';
import { getAlbums, createAlbum } from '../api/api';
import { Album } from '../../types';

const Dashboard: React.FC = () => {
  const [albums, setAlbums] = useState<Album[]>([]);
  const [isCreating, setIsCreating] = useState(false);
  const [newTitle, setNewTitle] = useState('');
  const [newDate, setNewDate] = useState('');
  
  const navigate = useNavigate();

  useEffect(() => {
    loadAlbums();
  }, []);

  const loadAlbums = async () => {
    try {
      const data = await getAlbums();
      setAlbums(data);
    } catch (error) {
      console.error('Failed to load albums', error);
    }
  };

  const handleCreateAlbum = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle || !newDate) return;

    try {
      await createAlbum({
        title: newTitle,
        date: newDate,
        coverUrl: `https://picsum.photos/400/300?random=${Date.now()}` // Random placeholder
      });
      setIsCreating(false);
      setNewTitle('');
      setNewDate('');
      loadAlbums();
    } catch (error) {
      alert('Error creating album');
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 pb-20">
      <Header />
      
      <main className="max-w-5xl mx-auto px-4 pt-8">
        <div className="flex justify-between items-end mb-8 border-b border-gray-200 pb-4">
          <div>
            <h2 className="text-2xl font-bold text-gray-800">Your Albums</h2>
            <p className="text-gray-500 mt-1">Manage and share your event collections</p>
          </div>
          <button 
            onClick={() => setIsCreating(!isCreating)}
            className="bg-brand-600 text-white px-4 py-2 rounded-md text-sm font-medium hover:bg-brand-700 shadow-sm flex items-center gap-2"
          >
            {isCreating ? 'Cancel' : '+ New Album'}
          </button>
        </div>

        {isCreating && (
          <div className="bg-white p-6 rounded-lg shadow-md mb-8 border border-brand-100 animate-fade-in">
            <h3 className="font-bold text-gray-700 mb-4">Create New Album</h3>
            <form onSubmit={handleCreateAlbum} className="flex flex-col md:flex-row gap-4 items-end">
              <div className="flex-1 w-full">
                <label className="block text-sm text-gray-600 mb-1">Event Title</label>
                <input 
                  type="text" 
                  value={newTitle}
                  onChange={e => setNewTitle(e.target.value)}
                  className="w-full p-2 border border-gray-300 rounded focus:border-brand-500 outline-none"
                  placeholder="e.g., Summer Wedding"
                  required
                />
              </div>
              <div className="w-full md:w-48">
                <label className="block text-sm text-gray-600 mb-1">Date</label>
                <input 
                  type="date" 
                  value={newDate}
                  onChange={e => setNewDate(e.target.value)}
                  className="w-full p-2 border border-gray-300 rounded focus:border-brand-500 outline-none"
                  required
                />
              </div>
              <button 
                type="submit" 
                className="bg-green-600 text-white px-6 py-2 rounded hover:bg-green-700 w-full md:w-auto"
              >
                Save
              </button>
            </form>
          </div>
        )}

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
          {albums.map((album) => (
            <AlbumCard 
              key={album.id} 
              album={album} 
              onClick={() => navigate(`/album/${album.id}`)}
            />
          ))}
        </div>

        {albums.length === 0 && !isCreating && (
          <div className="text-center py-20">
            <p className="text-gray-400 text-lg">No albums found. Create one to get started!</p>
          </div>
        )}
      </main>
    </div>
  );
};

export default Dashboard;