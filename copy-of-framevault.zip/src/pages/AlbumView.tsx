import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import Header from '../components/Header';
import PhotoUploader from '../components/PhotoUploader';
import AlbumGallery from '../components/AlbumGallery';
import { getAlbumById, getPhotosByAlbum, addPhoto, createShare } from '../api/api';
import { Album, Photo } from '../../types';

const AlbumView: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  
  const [album, setAlbum] = useState<Album | null>(null);
  const [photos, setPhotos] = useState<Photo[]>([]);
  const [loading, setLoading] = useState(true);
  const [shareLink, setShareLink] = useState<string | null>(null);

  useEffect(() => {
    if (id) {
      loadData(id);
    }
  }, [id]);

  const loadData = async (albumId: string) => {
    setLoading(true);
    try {
      const albumData = await getAlbumById(albumId);
      const photosData = await getPhotosByAlbum(albumId);
      setAlbum(albumData);
      setPhotos(photosData);
    } catch (error) {
      console.error("Error loading album");
      navigate('/');
    } finally {
      setLoading(false);
    }
  };

  const handlePhotoUpload = async (fileUrl: string) => {
    if (!album) return;
    try {
      const newPhoto = {
        albumId: album.id,
        url: fileUrl,
        dateAdded: new Date().toISOString()
      };
      await addPhoto(newPhoto);
      // Refresh photos
      const updatedPhotos = await getPhotosByAlbum(album.id);
      setPhotos(updatedPhotos);
    } catch (error) {
      alert("Failed to upload photo");
    }
  };

  const generateShareLink = async () => {
    if (!album) return;
    
    // Create a random token
    const token = Math.random().toString(36).substring(2, 15);
    
    try {
      await createShare({
        albumId: album.id,
        token: token
      });
      
      const link = `${window.location.origin}/#/s/${token}`;
      setShareLink(link);
    } catch (error) {
      alert("Failed to generate share link");
    }
  };

  if (loading) return <div className="p-10 text-center">Loading...</div>;
  if (!album) return <div className="p-10 text-center">Album not found</div>;

  return (
    <div className="min-h-screen bg-gray-50 pb-20">
      <Header />

      <main className="max-w-5xl mx-auto px-4 pt-8">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6 gap-4">
          <div>
            <button 
              onClick={() => navigate('/')} 
              className="text-gray-500 hover:text-brand-600 text-sm mb-2"
            >
              ← Back to Dashboard
            </button>
            <h2 className="text-3xl font-bold text-gray-800">{album.title}</h2>
            <p className="text-gray-500">{new Date(album.date).toLocaleDateString()} • {photos.length} Photos</p>
          </div>
          
          <div className="flex flex-col items-end gap-2">
            <button 
              onClick={generateShareLink}
              className="bg-indigo-600 text-white px-4 py-2 rounded-md hover:bg-indigo-700 transition shadow-sm"
            >
              Share Album
            </button>
            {shareLink && (
              <div className="bg-white p-2 border border-indigo-200 rounded text-sm text-indigo-700 break-all max-w-xs shadow-sm">
                 Link created: <br/>
                 <a href={shareLink} target="_blank" rel="noreferrer" className="underline font-bold">
                   Open Public Link
                 </a>
              </div>
            )}
          </div>
        </div>

        <PhotoUploader onUpload={handlePhotoUpload} />
        
        <div className="my-8 border-t border-gray-200" />
        
        <h3 className="text-xl font-semibold text-gray-700 mb-4">Gallery</h3>
        <AlbumGallery photos={photos} />
      </main>
    </div>
  );
};

export default AlbumView;