import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import AlbumGallery from '../components/AlbumGallery';
import { getShareByToken, getAlbumById, getPhotosByAlbum } from '../api/api';
import { Album, Photo } from '../../types';

const ShareView: React.FC = () => {
  const { token } = useParams<{ token: string }>();
  
  const [album, setAlbum] = useState<Album | null>(null);
  const [photos, setPhotos] = useState<Photo[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    if (token) {
      loadSharedAlbum(token);
    }
  }, [token]);

  const loadSharedAlbum = async (shareToken: string) => {
    try {
      const share = await getShareByToken(shareToken);
      if (!share) {
        setError('This share link is invalid or has expired.');
        setLoading(false);
        return;
      }

      const albumData = await getAlbumById(share.albumId);
      const photosData = await getPhotosByAlbum(share.albumId);
      
      setAlbum(albumData);
      setPhotos(photosData);
    } catch (err) {
      setError('Failed to load shared album.');
    } finally {
      setLoading(false);
    }
  };

  if (loading) return <div className="p-20 text-center text-gray-500">Loading shared album...</div>;
  
  if (error) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-100">
        <div className="bg-white p-8 rounded-lg shadow-md text-center max-w-md">
          <h2 className="text-xl font-bold text-red-500 mb-2">Access Denied</h2>
          <p className="text-gray-600">{error}</p>
        </div>
      </div>
    );
  }

  if (!album) return null;

  return (
    <div className="min-h-screen bg-white">
      {/* Public Header - No Login Info */}
      <header className="bg-white border-b border-gray-100 py-6 mb-8 text-center shadow-sm">
        <h1 className="text-2xl font-bold text-gray-800">{album.title}</h1>
        <p className="text-gray-500 mt-1">Shared via FrameVault • {new Date(album.date).toLocaleDateString()}</p>
      </header>

      <main className="max-w-6xl mx-auto px-4 pb-20">
        <AlbumGallery photos={photos} />
      </main>

      <footer className="fixed bottom-0 w-full bg-gray-50 border-t border-gray-200 py-3 text-center text-xs text-gray-400">
        Powered by FrameVault
      </footer>
    </div>
  );
};

export default ShareView;